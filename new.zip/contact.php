<?php include 'includes/header.php'; ?>	
	<!-- contact-page -->
	<div class="contact">
		<div class="container"> 
			<h3 class="_winkls-title _winkls-title1">Contact Us</h3>  
			<div class="map-info">
				<div class="col-md-6 map-grids">
					<h4>Our Store1</h4>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3023.9503398796587!2d-73.9940307!3d40.719109700000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a27e2f24131%3A0x64ffc98d24069f02!2sCANADA!5e0!3m2!1sen!2sin!4v1441710758555"></iframe>
				</div>
				<div class="col-md-6 map-grids">
					<h4>Our Store2</h4>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d23778.253788067046!2d-87.77626504212625!3d41.84376259112007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e33967c81db8f%3A0xbc5872c77c003120!2sCicero%2C+IL!5e0!3m2!1sen!2sin!4v1470650895897"></iframe>
				</div>   
				<div class="col-md-6 map-grids">
					<h4>Our Store3</h4>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4851.135123262741!2d105.86847248902144!3d58.25136049196456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5cf6e6f5eed7e5eb%3A0xfec064728556bbad!2sTokma%2C+Irkutsk+Oblast%2C+Russia%2C+666639!5e0!3m2!1sen!2sin!4v1470650971228"></iframe>
				</div>   
				<div class="col-md-6 map-grids">
					<h4>Our Store4</h4>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3023.9503398796587!2d-73.9940307!3d40.719109700000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a27e2f24131%3A0x64ffc98d24069f02!2sCANADA!5e0!3m2!1sen!2sin!4v1441710758555" allowfullscreen=""></iframe>
				</div> 
				<div class="clearfix"> </div>
			</div>  
			<div class="contact-form-row">
				<h3 class="_winkls-title _winkls-title1">Drop Us a line</h3>  
				<div class="col-md-7 contact-left">
					<form action="#" method="post">
						<input type="text" name="Name" placeholder="Name" required="">
						<input class="email" type="text" name="Email" placeholder="Email" required="">
						<textarea placeholder="Message" name="Message" required=""></textarea>
						<input type="submit" value="SUBMIT">
					</form>
				</div> 
				<div class="col-md-4 contact-right">
					<div class="cnt-_winkagile-row">
						<div class="col-md-3 contact-_winkicon">
							<i class="fa fa-truck" aria-hidden="true"></i>
						</div>
						<div class="col-md-9 contact-_winktext">
							<p>Manage Your Orders <br>Easily Track Orders & Returns </p> 
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="cnt-_winkagile-row cnt-_winkagile-row-mdl">
						<div class="col-md-3 contact-_winkicon">
							<i class="fa fa-bell" aria-hidden="true"></i>
						</div>
						<div class="col-md-9 contact-_winktext">
							<p>Notifications <br>Get Relevant Alerts & Recommendations</p> 
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="cnt-_winkagile-row">
						<div class="col-md-3 contact-_winkicon">
							<i class="fa fa-heart" aria-hidden="true"></i>
						</div>
						<div class="col-md-9 contact-_winktext">
							<p>Requirements<br> With Wishlists, Reviews, Ratings</p> 
						</div>
						<div class="clearfix"> </div>
					</div>
				</div> 
				<div class="clearfix"> </div>	
			</div>
		</div>
	</div>
	<!-- //contact-page --> 
<?php include 'includes/footer.php'; ?>